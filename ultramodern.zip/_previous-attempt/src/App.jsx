import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { BrowserRouter, Link, Navigate, useLocation } from 'react-router-dom';
import redirects from './data/generated/redirects.json';
import { projects } from './data/projects.js';

const company = 'UltraModern Technologies';
const redirectBySlug = new Map(redirects.map((redirect) => [redirect.from.toLowerCase(), `/${redirect.to}`]));

function PageMeta({ title, description }) {
  return (
    <Helmet>
      <title>{title ? `${title} | ${company}` : `${company} | Digital products, thoughtfully built`}</title>
      {description && <meta name="description" content={description} />}
    </Helmet>
  );
}

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className="site-header">
      <div className="header-inner">
        <Link className="brand" to="/" aria-label={`${company} home`} onClick={closeMenu}>
          <img src="/IMG/ULTRAMODERN TECHNOLOGIES LOGO.png" alt="" />
          <span>UltraModern<span className="brand-dot">.</span></span>
        </Link>
        <button
          className="menu-toggle"
          type="button"
          aria-expanded={menuOpen}
          aria-label={menuOpen ? 'Close navigation' : 'Open navigation'}
          onClick={() => setMenuOpen((open) => !open)}
        >
          <span />
          <span />
        </button>
        <nav className={menuOpen ? 'main-nav is-open' : 'main-nav'} aria-label="Main navigation">
          <Link to="/" onClick={closeMenu}>Home</Link>
          <Link to="/services" onClick={closeMenu}>Services</Link>
          <Link to="/portfolio" onClick={closeMenu}>Portfolio</Link>
          <Link to="/about" onClick={closeMenu}>About</Link>
          <Link to="/blog" onClick={closeMenu}>Insights</Link>
          <Link className="nav-cta" to="/contact" onClick={closeMenu}>Let’s talk <span aria-hidden="true">↗</span></Link>
        </nav>
      </div>
    </header>
  );
}

function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-inner">
        <div>
          <Link className="footer-brand" to="/">UltraModern<span className="brand-dot">.</span></Link>
          <p>Thoughtful digital experiences, made for what’s next.</p>
        </div>
        <div className="footer-links">
          <Link to="/services">Services</Link>
          <Link to="/portfolio">Portfolio</Link>
          <Link to="/career">Careers</Link>
          <Link to="/privacy-policy">Privacy</Link>
          <Link to="/contact">Contact</Link>
        </div>
        <span className="footer-copy">© {new Date().getFullYear()} UltraModern Technologies</span>
      </div>
    </footer>
  );
}

function Shell({ children }) {
  return (
    <>
      <Header />
      <main>{children}</main>
      <Footer />
    </>
  );
}

function Eyebrow({ children }) {
  return <span className="eyebrow"><span />{children}</span>;
}

function ProjectMockup({ project }) {
  const screens = {
    grovio: (
      <div className="mock-screen grovio-screen">
        <div className="mock-topline"><b>grovio</b><span>Shop&nbsp;&nbsp; Stories&nbsp;&nbsp; About</span><i>bag&nbsp; 0</i></div>
        <div className="mock-grovio-copy"><small>GOOD THINGS GROW HERE</small><strong>A little more<br />good in every day.</strong><span>Explore the collection&nbsp; →</span></div>
        <div className="mock-produce"><span>✳</span><i>✦</i><b>●</b></div>
        <div className="mock-bottomline"><span>Made for everyday living</span><span>01 — 03</span></div>
      </div>
    ),
    ride: (
      <div className="mock-screen ride-screen">
        <div className="mock-appbar"><b>ride<span>go</span></b><i>☰</i></div>
        <div className="mock-map"><span className="map-road road-one" /><span className="map-road road-two" /><span className="map-route" /><i className="map-pin pin-start">●</i><i className="map-pin pin-end">●</i><div className="map-caption">Your city, your way.</div></div>
        <div className="mock-ride-panel"><span>YOUR DESTINATION</span><b>Where would you like to go?</b><i>Find a ride&nbsp; →</i></div>
      </div>
    ),
    property: (
      <div className="mock-screen property-screen">
        <div className="mock-property-nav"><b>habitat<span>.</span></b><span>Buy&nbsp;&nbsp; Rent&nbsp;&nbsp; Explore</span><i>⌕</i></div>
        <div className="mock-property-hero"><small>FIND YOUR PLACE</small><strong>A place to<br />call your own.</strong><span>Discover homes that feel right.</span></div>
        <div className="mock-property-search"><span>Location&nbsp;&nbsp;⌄</span><span>Property type&nbsp;&nbsp;⌄</span><b>Search homes&nbsp; →</b></div>
      </div>
    ),
    transport: (
      <div className="mock-screen transport-screen">
        <div className="mock-transport-nav"><b>KHUSHI <span>TRANSPORT</span></b><i>Reliable, every mile.</i></div>
        <div className="mock-transport-hero"><small>MOVE WITH CONFIDENCE</small><strong>Logistics that<br />keep you moving.</strong><span>Routes, fleet, and dependable delivery.</span><b>Request a quote&nbsp; →</b></div>
        <div className="mock-truck"><span>KHUSHI</span><i /></div>
      </div>
    ),
  };

  return (
    <div className={`project-preview project-preview-${project.tone}`} aria-label={`${project.name} visual preview`}>
      {project.image ? (
        <img src={project.image} alt={project.alt} loading="lazy" />
      ) : (
        <div className="mock-browser">
          <div className="mock-controls"><i /><i /><i /><span>{project.name.toLowerCase().replaceAll(' ', '')}.com</span><b>↗</b></div>
          {screens[project.preview]}
        </div>
      )}
    </div>
  );
}

function ProjectCard({ project, index }) {
  return (
    <article className="project-card" style={{ '--card-index': index }}>
      <ProjectMockup project={project} />
      <div className="project-card-info">
        <div className="project-card-heading">
          <div><span className="project-category">{project.category}</span><h3>{project.name}</h3></div>
          <span className="project-arrow" aria-hidden="true">↗</span>
        </div>
        <p>{project.description}</p>
      </div>
    </article>
  );
}

function Projects({ compact = false }) {
  const shownProjects = compact ? projects.slice(0, 3) : projects;

  return (
    <div className={compact ? 'projects-grid projects-grid-compact' : 'projects-grid'}>
      {shownProjects.map((project, index) => <ProjectCard key={project.name} project={project} index={index} />)}
    </div>
  );
}

function HomePage() {
  return (
    <>
      <PageMeta description="We design and build digital products, websites, and software that help businesses move forward." />
      <section className="home-hero">
        <div className="hero-glow hero-glow-one" />
        <div className="hero-glow hero-glow-two" />
        <div className="page-width hero-content">
          <Eyebrow>Digital studio · Indore, India</Eyebrow>
          <h1>We make digital<br /><span>feel human.</span></h1>
          <p>We turn ambitious ideas into thoughtful websites, products, and software built to make a real difference.</p>
          <div className="hero-actions">
            <Link className="button button-dark" to="/contact">Let’s build something <span>↗</span></Link>
            <Link className="text-link" to="/portfolio">Explore our work <span>↓</span></Link>
          </div>
          <div className="hero-note"><span className="note-dash" /> Strategy, design & engineering — all under one roof</div>
          <div className="hero-stamp"><span>BUILDING<br />WHAT’S NEXT</span><b>✳</b></div>
        </div>
        <div className="hero-bottom page-width"><span>Scroll to discover</span><span>01 / 04</span></div>
      </section>

      <section className="intro-section page-width">
        <div className="intro-kicker"><Eyebrow>More than a dev shop</Eyebrow><span>01 — The approach</span></div>
        <div className="intro-copy">
          <h2>Great work starts with <span>getting curious.</span></h2>
          <p>We partner with people who want to move their business forward. First we listen, then we bring the right mix of design, technology, and care to build what comes next.</p>
          <Link className="underlined-link" to="/about">Get to know us <span>↗</span></Link>
        </div>
      </section>

      <section className="home-projects section-pad">
        <div className="page-width">
          <div className="section-heading">
            <div><Eyebrow>A few things we’ve made</Eyebrow><h2>Work with <span>purpose.</span></h2></div>
            <Link className="underlined-link" to="/portfolio">All projects <span>↗</span></Link>
          </div>
          <Projects compact />
        </div>
      </section>

      <section className="home-services page-width">
        <div><Eyebrow>What we do</Eyebrow><h2>Good ideas deserve<br /><span>great execution.</span></h2></div>
        <div className="service-teaser-list">
          {['Digital products & software', 'Websites & e-commerce', 'Mobile apps', 'Digital growth & strategy'].map((item, index) => (
            <Link key={item} to="/services"><span>0{index + 1}</span>{item}<b>↗</b></Link>
          ))}
          <Link className="service-all" to="/services">Explore all capabilities <span>↗</span></Link>
        </div>
      </section>

      <Callout />
    </>
  );
}

function Callout() {
  return (
    <section className="callout-section">
      <div className="page-width callout-inner">
        <Eyebrow>Have a good one?</Eyebrow>
        <h2>Let’s make it<br /><span>real.</span></h2>
        <Link className="button button-light" to="/contact">Start a conversation <span>↗</span></Link>
        <div className="callout-orbit" aria-hidden="true">✳</div>
      </div>
    </section>
  );
}

function PortfolioPage() {
  return (
    <>
      <PageMeta title="Portfolio" description="Explore websites and digital products designed and developed by UltraModern Technologies." />
      <section className="page-hero page-width">
        <div className="page-hero-copy">
          <Eyebrow>A selection of our work</Eyebrow>
          <h1>Made with care.<br /><span>Built to matter.</span></h1>
          <p>From useful everyday tools to ambitious digital experiences, here are some of the things we’ve helped bring to life.</p>
        </div>
        <div className="portfolio-counter"><strong>{String(projects.length).padStart(2, '0')}</strong><span>projects<br />and counting</span></div>
      </section>
      <section className="portfolio-content page-width">
        <div className="portfolio-toolbar"><span>Selected projects</span><span>All industries&nbsp; · &nbsp;{projects.length} projects</span></div>
        <Projects />
      </section>
      <Callout />
    </>
  );
}

function SectionParts({ parts = [] }) {
  return parts.map((part, index) => {
    const key = `${part.type}-${index}`;
    if (part.type === 'text' || part.type === 'subheading') {
      return <div className={part.type === 'subheading' ? 'content-subheading' : 'content-richtext'} key={key} dangerouslySetInnerHTML={{ __html: part.items?.join(' ') || part }} />;
    }
    if (part.type === 'list') {
      return <ul className="content-list" key={key}>{part.items.map((item, itemIndex) => <li key={itemIndex} dangerouslySetInnerHTML={{ __html: item }} />)}</ul>;
    }
    if (part.type === 'image') {
      return part.items.map((image, imageIndex) => <img className="content-image" key={`${key}-${imageIndex}`} src={image.src} alt={image.alt || ''} loading="lazy" />);
    }
    if (part.type === 'cards') {
      return <div className="content-card-grid" key={key}>{part.items.map((card, cardIndex) => (
        <article className="content-card" key={`${key}-${cardIndex}`}>
          <span className="content-card-index">{String(cardIndex + 1).padStart(2, '0')}</span>
          <h3 dangerouslySetInnerHTML={{ __html: card.title || '' }} />
          {card.text?.map((text, textIndex) => <p key={textIndex} dangerouslySetInnerHTML={{ __html: text }} />)}
          {card.list?.length > 0 && <ul>{card.list.map((text, textIndex) => <li key={textIndex} dangerouslySetInnerHTML={{ __html: text }} />)}</ul>}
        </article>
      ))}</div>;
    }
    if (part.type === 'stats') {
      return <div className="content-stats" key={key}>{part.items.map((item, itemIndex) => <div key={itemIndex}><strong>{item.value}</strong><span>{item.label}</span></div>)}</div>;
    }
    if (part.type === 'chips') {
      return <div className="content-chips" key={key}>{part.items.map((item, itemIndex) => <span key={itemIndex}>{item.text}</span>)}</div>;
    }
    if (part.type === 'faq') {
      return <details className="content-faq" key={key}><summary>{part.items[0]?.q}<span>+</span></summary><div dangerouslySetInnerHTML={{ __html: part.items[0]?.a || '' }} /></details>;
    }
    if (part.type === 'buttons') {
      return <div className="content-buttons" key={key}>{part.items.map((item, itemIndex) => <a className="button button-dark" href={item.href || '/contact'} key={itemIndex}>{item.text}<span>↗</span></a>)}</div>;
    }
    if (part.type === 'jobs') {
      return <div className="content-card-grid" key={key}>{part.items.map((item, itemIndex) => <article className="content-card" key={itemIndex}><h3>{item.title}</h3><p>{item.desc}</p><div className="content-chips">{item.tags?.map((tag) => <span key={tag}>{tag}</span>)}</div></article>)}</div>;
    }
    return null;
  });
}

function ContentPage({ page }) {
  const title = page.hero?.title || page.meta?.title || page.slug;
  return (
    <>
      <PageMeta title={page.meta?.title || title} description={page.meta?.description} />
      <section className="page-hero page-width content-page-hero">
        <div className="page-hero-copy">
          <Eyebrow>{page.hero?.badge || 'UltraModern Technologies'}</Eyebrow>
          <h1>{title}</h1>
          {page.hero?.text?.map((text, index) => <p key={index} dangerouslySetInnerHTML={{ __html: text }} />)}
          {!page.hero?.text?.length && <p>{page.meta?.description}</p>}
        </div>
      </section>
      <div className="content-sections page-width">
        {page.sections?.map((section, index) => (
          <section className="content-section" id={section.id} key={`${section.title || section.kind}-${index}`}>
            {(section.title || section.badge) && <div className="content-section-header">{section.badge && <Eyebrow>{section.badge}</Eyebrow>}{section.title && <h2>{section.title}</h2>}</div>}
            <SectionParts parts={section.parts} />
          </section>
        ))}
        <div className="content-end-link"><Link className="underlined-link" to="/contact">Talk to our team <span>↗</span></Link></div>
      </div>
    </>
  );
}

function ServicesPage({ services }) {
  return (
    <>
      <PageMeta title="Services" description="Explore software, website, mobile app, and digital growth services from UltraModern Technologies." />
      <section className="page-hero page-width">
        <div className="page-hero-copy"><Eyebrow>What we’re good at</Eyebrow><h1>One team for<br /><span>the whole journey.</span></h1><p>From the first sketch to launch day and beyond, find the right expertise to move your idea forward.</p></div>
      </section>
      <section className="directory-section page-width">
        <div className="portfolio-toolbar"><span>Our capabilities</span><span>{services.length} service areas</span></div>
        <div className="directory-grid">{services.map((service, index) => (
          <Link className="directory-card" to={`/${service.slug}`} key={service.slug}>
            <span className="directory-index">{String(index + 1).padStart(2, '0')}</span>
            <h2>{service.hero?.title || service.meta?.title}</h2>
            <p>{service.meta?.description}</p>
            <span className="directory-arrow">↗</span>
          </Link>
        ))}</div>
      </section>
    </>
  );
}

function BlogPage({ blogs }) {
  return (
    <>
      <PageMeta title="Insights" description="Ideas and guidance on technology, digital products, and business growth." />
      <section className="page-hero page-width"><div className="page-hero-copy"><Eyebrow>Notes from the studio</Eyebrow><h1>Ideas worth<br /><span>thinking about.</span></h1><p>Practical perspectives on technology, digital experiences, and building a business that’s ready for what’s next.</p></div></section>
      <section className="blog-grid page-width">{blogs.map((blog) => (
        <Link className="blog-card" to={`/${blog.slug}`} key={blog.slug}>
          {blog.cover && <img src={blog.cover} alt="" loading="lazy" />}
          <span>{blog.date} &nbsp;·&nbsp; {blog.readingMinutes} min read</span>
          <h2>{blog.title}</h2>
          <p>{blog.excerpt}</p>
          <b>Read article&nbsp; ↗</b>
        </Link>
      ))}</section>
    </>
  );
}

function BlogDetail({ blog }) {
  return (
    <>
      <PageMeta title={blog.meta?.title || blog.title} description={blog.meta?.description || blog.excerpt} />
      <article className="blog-article page-width">
        <Link className="underlined-link" to="/blog">← All insights</Link>
        <div className="article-heading"><Eyebrow>{blog.date} · {blog.readingMinutes} min read</Eyebrow><h1>{blog.title}</h1><p>{blog.excerpt}</p></div>
        {blog.cover && <img className="article-cover" src={blog.cover} alt="" />}
        <div className="article-content" dangerouslySetInnerHTML={{ __html: blog.content }} />
      </article>
    </>
  );
}

function PrivacyPage({ privacy }) {
  return (
    <>
      <PageMeta title={privacy.meta?.title || 'Privacy Policy'} description={privacy.meta?.description} />
      <section className="page-hero page-width"><div className="page-hero-copy"><Eyebrow>Your information matters</Eyebrow><h1>Privacy,<br /><span>in plain terms.</span></h1><p>How we collect, use, and protect the information you share with us.</p></div></section>
      <div className="privacy-content page-width">{privacy.sections.map((section) => <section id={section.id} key={section.id}><Eyebrow>{section.tag}</Eyebrow><h2>{section.title}</h2><div dangerouslySetInnerHTML={{ __html: section.html }} /></section>)}</div>
    </>
  );
}

function NotFound() {
  return <section className="not-found page-width"><Eyebrow>404 · Page not found</Eyebrow><h1>We took a wrong<br /><span>turn somewhere.</span></h1><Link className="button button-dark" to="/">Back to home <span>↗</span></Link></section>;
}

function PageRouter() {
  const { pathname } = useLocation();
  const path = decodeURIComponent(pathname).replace(/^\/+|\/+$/g, '').toLowerCase();
  const redirect = redirectBySlug.get(path);
  const [routeData, setRouteData] = useState(null);
  let contentType = path && !['portfolio', 'work'].includes(path) ? 'service' : null;
  if (path === 'services') contentType = 'services-index';
  else if (path === 'blog' || path === 'insights') contentType = 'blogs-index';
  else if (path === 'privacy-policy') contentType = 'privacy';
  else if (['about', 'contact', 'career'].includes(path)) contentType = 'static';
  else if (/-jobs?$/.test(path)) contentType = 'job';
  else if (/-blog$/.test(path)) contentType = 'blog';

  useEffect(() => {
    let active = true;
    setRouteData(null);
    if (!contentType) return () => { active = false; };
    const loadPageData = async () => {
      try {
        let module;
        if (contentType === 'services-index' || contentType === 'service') {
          module = await import('./data/generated/services.json');
        } else if (contentType === 'blogs-index' || contentType === 'blog') {
          module = await import('./data/generated/blogs.json');
        } else if (contentType === 'job') {
          module = await import('./data/generated/jobs.json');
        } else if (contentType === 'static') {
          module = await import('./data/generated/static-pages.json');
        } else {
          module = await import('./data/generated/privacy.json');
        }
        if (active) setRouteData({ type: contentType, data: module.default });
      } catch (error) {
        console.error(`Unable to load ${contentType} page content`, error);
        if (active) setRouteData({ type: contentType, error });
      }
    };
    loadPageData();
    return () => { active = false; };
  }, [contentType, path]);

  if (!path) return <HomePage />;
  if (path === 'portfolio' || path === 'work') return <PortfolioPage />;
  if (redirect) return <Navigate to={redirect} replace />;
  if (routeData?.error && routeData.type === contentType) {
    return <div className="page-width content-load-error" role="alert">This page could not be loaded. Please refresh and try again.</div>;
  }
  if (!routeData || routeData.type !== contentType) {
    return <div className="page-width content-loading" aria-live="polite">Loading page…</div>;
  }
  if (contentType === 'services-index') return <ServicesPage services={routeData.data} />;
  if (contentType === 'blogs-index') return <BlogPage blogs={routeData.data} />;
  if (contentType === 'privacy') return <PrivacyPage privacy={routeData.data} />;
  if (contentType === 'static') {
    const page = routeData.data.find((item) => item.slug === path);
    return page ? <ContentPage page={page} /> : <NotFound />;
  }
  const page = routeData.data.find((item) => item.slug.toLowerCase() === path);
  if (!page) return <NotFound />;
  return contentType === 'blog' ? <BlogDetail blog={page} /> : <ContentPage page={page} />;
}

function App() {
  return <Shell><PageRouter /></Shell>;
}

export default function Root() {
  return (
    <BrowserRouter>
      <App />
    </BrowserRouter>
  );
}
