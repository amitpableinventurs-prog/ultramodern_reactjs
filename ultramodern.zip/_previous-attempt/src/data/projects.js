export const projects = [
  {
    name: 'SS Maintenance',
    category: 'On-demand services',
    description:
      'A home-services platform that brings service requests and local professionals into one simple experience.',
    image: '/IMG/ss.png',
    alt: 'SS Maintenance project artwork',
    tone: 'blue',
  },
  {
    name: 'Roommates.com',
    category: 'Community & housing',
    description:
      'A roommate discovery experience for finding compatible people and exploring rental opportunities.',
    image: '/IMG/APPARTMENTS.png',
    alt: 'Roommates.com project artwork',
    tone: 'violet',
  },
  {
    name: 'ThinkWave',
    category: 'Education',
    description:
      'A school management experience for classroom coordination, academic progress, and communication.',
    image: '/IMG/thinkwave.png',
    alt: 'ThinkWave project artwork',
    tone: 'cyan',
  },
  {
    name: 'EYOM Shopping',
    category: 'Commerce & services',
    description:
      'An integrated shopping and household-services experience built around everyday home needs.',
    image: '/IMG/Eyom.png',
    alt: 'EYOM Shopping project artwork',
    tone: 'orange',
  },
  {
    name: 'Bharat Clothing Factory',
    category: 'Manufacturing',
    description:
      'A digital storefront presenting custom apparel, corporate branding, and manufacturing capabilities.',
    image: '/IMG/bharat.png',
    alt: 'Bharat Clothing Factory project artwork',
    tone: 'red',
  },
  {
    name: 'Recoup Physiotherapy',
    category: 'Healthcare',
    description:
      'A clinic website designed to make services easy to explore and appointment enquiries easy to start.',
    image: '/IMG/recoup.png',
    alt: 'Recoup Physiotherapy project artwork',
    tone: 'green',
  },
  {
    name: 'Grovio',
    category: 'Digital product',
    description:
      'A fresh, product-led digital storefront concept with clear discovery and a streamlined shopping flow.',
    preview: 'grovio',
    tone: 'green',
  },
  {
    name: 'Ride & Transport',
    category: 'Mobility',
    description:
      'A mobility product concept focused on simple trip discovery, transparent fares, and easy booking.',
    preview: 'ride',
    tone: 'blue',
  },
  {
    name: 'Real Estate',
    category: 'Property',
    description:
      'A property discovery concept that brings listing details, imagery, and enquiry actions together.',
    preview: 'property',
    tone: 'violet',
  },
  {
    name: 'Khushi Transport',
    category: 'Transport & logistics',
    description:
      'A transport service concept that makes routes, fleet capabilities, and quote requests easy to find.',
    preview: 'transport',
    tone: 'orange',
  },
];
